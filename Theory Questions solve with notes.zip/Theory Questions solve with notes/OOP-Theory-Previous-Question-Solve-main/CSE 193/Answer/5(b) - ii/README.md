# Output

```JAVA
Start Change
Inner Catch 1
Inside finally block
End Change
```