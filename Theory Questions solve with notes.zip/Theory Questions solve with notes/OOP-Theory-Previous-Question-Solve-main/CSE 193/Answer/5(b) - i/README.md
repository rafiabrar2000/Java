# Output

```JAVA
Exception created.. 
Exception: Divide by 0
```