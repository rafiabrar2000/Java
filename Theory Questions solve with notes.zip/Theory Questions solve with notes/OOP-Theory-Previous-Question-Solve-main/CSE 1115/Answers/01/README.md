# b) Did you declare Person as an abstract class or an interface? Briefly provide reasoning for your choice.

I declared Person as an abstract class.
The reasons behind that:

(Benefits of abstract class from the Internet)

- An abstract class cannot be instantiated. The purpose of an abstract class is to provide a common definition of a base class that multiple derived classes can share

- Abstract class in Java is highly beneficial in writing shorter codes.

- Abstraction in Java avoids code duplication.

- Abstract classes enable code reusability.

- Changes to internal code implementation are done without affecting classes