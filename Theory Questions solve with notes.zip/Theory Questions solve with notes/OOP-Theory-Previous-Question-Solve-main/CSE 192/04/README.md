# Output

```JAVA
 Inside foo
```