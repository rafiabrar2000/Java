# Output

```JAVA
 ArrayList: [ C, null,  A, null]
 HasMap: {null=null, 1= A, 2= B, 3=null}
```