# Input - Output

```JAVA
Inputs
a = 0, b = 0
a = 1, b = 0
a = 1, b = 1
```

```JAVA
Outputs
4
 END

5
 END

 END

```