public class TestFinal{
    public final int studentID = 10;
    public final void display(){
        System.out.println("Final method can not be override");
    }
}