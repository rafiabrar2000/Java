public class IfTest{
    public static void main(String[] args){
        int x = (int) (Math.random() * 100);
        System.out.println(x);
        // if else statement 

        if (x>100)
        {
            System.out.println("White");
        }
        else
        {
            System.out.println("Black");
        }
    }
}