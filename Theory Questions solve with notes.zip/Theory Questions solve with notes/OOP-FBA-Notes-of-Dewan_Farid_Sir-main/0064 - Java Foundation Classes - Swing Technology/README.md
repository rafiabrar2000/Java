The Java Foundation Classes (J.F.C.)/ Swing technology is a second-generation GUI toolkit that is included in the Java 2 SDK as a standard extension.



Swing technology has many improvement over AWT and adds many new
and more-complex components including a table and tree component.