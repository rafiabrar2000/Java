public class Car {

}

// or we can declare the Car class by
// extending Object class. Both have same meaning.

public class Car extends Object {
  
}
