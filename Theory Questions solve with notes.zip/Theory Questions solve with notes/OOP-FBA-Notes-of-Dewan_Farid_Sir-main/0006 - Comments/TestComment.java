public class TestComment{
    // comment on one line

    public static void main(String[] args){
        /* comment on one
        or more lines
        */
        System.out.println("Comments in Java");
    }

    /** documentation comment
     *  can also span one or more lines
     */
}