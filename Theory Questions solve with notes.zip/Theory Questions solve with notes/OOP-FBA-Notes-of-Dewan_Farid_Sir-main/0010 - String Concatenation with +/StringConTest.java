public class StringConTest{
    public static void main(String[] args){
        String salutation = "Mr. ";
        String name = "Dewan " + "Md. " + "Farid" ;
        String title = salutation + name;
        System.out.println(title); 
    }
}