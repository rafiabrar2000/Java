public class TesttoString {
    public static void main(String[] args) {
        TesttoString now = new TesttoString();
        System.out.println(now.toString());
        // is equavalent to :
        System.out.println(now.toString());
    }
}