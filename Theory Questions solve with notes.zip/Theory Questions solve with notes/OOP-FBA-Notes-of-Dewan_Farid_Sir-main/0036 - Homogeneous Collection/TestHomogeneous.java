public static TestHomogeneous {
  public static void main(String[] args){
    TestHomogeneous[] arr = new TestHomogeneous[3];

    arr[0] = new TestHomogeneous();
    arr[1] = new TestHomogeneous();
    arr[2] = new TestHomogeneous(); 
  }
}
