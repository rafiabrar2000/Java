# OOP(Theory) Questions of Mid & Final (Previous Batch)

## Institute: United International University


<br>


<hr>

<h2 align="center"> Course Syllabus </h2>



[Go to the folder =>](https://github.com/FahimFBA/Previous-OOP-Questions/tree/main/Syllabus)

<hr>





<h2 align="center"> Mid-Term </h2>



[Go to the folder =>](https://github.com/FahimFBA/Previous-OOP-Questions/tree/main/Mid)

<hr>

<br>


<h2 align="center"> Final-Term </h2>



[Go to the folder =>](https://github.com/FahimFBA/Previous-OOP-Questions/tree/main/Final)

<hr>


<br>
<h5 align="right">Special thanks goes to my friend, Dip Saha  </h5>